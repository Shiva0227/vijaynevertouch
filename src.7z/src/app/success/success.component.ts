import { Component, OnInit } from '@angular/core';
import { IGames } from '../play/games';
import { PlayserviceService } from '../playservice.service';

@Component({
  selector: 'app-success',
  templateUrl: './success.component.html',
  styleUrls: ['./success.component.css']
})
export class SuccessComponent implements OnInit {
  games:IGames[];
  cardBalance=this.service.balance;
  isPlayed:boolean;
  gameName:string;
  constructor(private service:PlayserviceService) { }

  ngOnInit() {
    this.service.getGames().subscribe(data=>this.games=data);
  }
  playGame(g){

if(this.cardBalance>=g.gamePrice){
  this.cardBalance =this.cardBalance-g.gamePrice;
  this.gameName=g.gameName;
  this.isPlayed=true;
  

}
else{
  this.gameName=g.gameName;
  this.isPlayed=false;
}
  }

}
