import { TestBed } from '@angular/core/testing';

import { PlayserviceService } from './playservice.service';

describe('PlayserviceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PlayserviceService = TestBed.get(PlayserviceService);
    expect(service).toBeTruthy();
  });
});
