import { Injectable } from '@angular/core';
import{HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
import { IGames } from './play/games';
@Injectable({
  providedIn: 'root'
})
export class PlayserviceService {
  url:string="/assets/GameList.json";
  balance=600;
  constructor(private http:HttpClient) { }
  getGames():Observable<IGames []>{
    return this.http.get<IGames []>(this.url); 
  }
}
