import { Component, OnInit } from '@angular/core';
import { IGames } from './games';
import { PlayserviceService } from '../playservice.service';

@Component({
  selector: 'app-play',
  templateUrl: './play.component.html',
  styleUrls: ['./play.component.css']
})
export class PlayComponent implements OnInit {
games:IGames[];

  constructor(private service:PlayserviceService) { }

  ngOnInit() {
    this.service.getGames().subscribe(data=>this.games=data);
  }
  

}
