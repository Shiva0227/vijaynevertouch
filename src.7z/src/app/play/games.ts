export interface IGames{
gameId:number;
gameName:string;
gamePrice:number;
}